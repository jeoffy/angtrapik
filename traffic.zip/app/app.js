'use strict';

// Declare app level module which depends on views, and components
angular.module('roadTraffic', [
  'ngRoute',
  'roadTraffic.traffic',
  'roadTraffic.routing' 
]).
config(['$locationProvider', '$routeProvider', function($locationProvider, $routeProvider) {
  $locationProvider.hashPrefix('!');

  $routeProvider.otherwise({redirectTo: '/traffic'});
}])

.controller('MainCtrl', ['$scope', '$location', '$route', '$http', function($scope, $location, $route, $http) {
 	
 	$scope.siteTitle = "Ang Trapik";
    $scope.fast ="Fast";
	$scope.slow ="Slow";
	$scope.quickAccess ="Quick access ";
	$scope.trafficUpdate ="Traffic Update";
	$scope.streetPhoto ="Street View";
	$scope.footer ="Copyrights 2016. Angtrapik.com";

	// Menu navigation active class
	$scope.activePath = null;
	$scope.$on('$routeChangeSuccess', function(){
    	$scope.activePath = $location.path();
    	console.log( $location.path() );
  	});

	// get quick access data in json
  	$http.get('json/quickaccess.json').success(function(data){
  		//console.log(data);
  		$scope.places = data;
  	});

}]);