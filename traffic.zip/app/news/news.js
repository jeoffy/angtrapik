'use strict';

angular.module('roadTraffic.news', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/news', {
    templateUrl: 'news/news.html',
    controller: 'NewsCtrl'
  });
}])

.controller('NewsCtrl', ['$scope', '$http', function($scope,  $http) {

	var platform = new H.service.Platform({
	  'app_id': 'XrO29mOZYrddKOcalMB0',
	  'app_code': 'MG9xBPwbf5UTj9pCnF-6Rw'
	});
	console.log(platform); 

	$scope.findway = function() { 

		$('#mapContainer').css('display', 'block');

		var geocoder = new google.maps.Geocoder();
	    var firstAddress = $scope.fromLocation;
	    var secAddress = $scope.toLocation;

	    //console.log(address1);

	    geocoder.geocode( { 'address': firstAddress}, function addOne(result,   status) {  
		    if (status == google.maps.GeocoderStatus.OK) { 
					var firstLat = result[0].geometry.location.lat();
			        var firstLong = result[0].geometry.location.lng();  

			        secAdd(firstLat, firstLong); 
			}  
	    }); 

	    function secAdd(firstLat, firstLong){ 
		    geocoder.geocode( {'address': secAddress}, function addTwo(result,   status) {  
			    if (status == google.maps.GeocoderStatus.OK) {  
				        var secLat = result[0].geometry.location.lat();
				        var secLong = result[0].geometry.location.lng();

				        console.log(firstLat);
						console.log(firstLong);  
						console.log(secLat);
						console.log(secLong);

						 /* HERE API  START */ 

					    // Retrieve the target element for the map:
						var targetElement = document.getElementById('mapContainer');

						// Get the default map types from the platform object:
						var defaultLayers = platform.createDefaultLayers();

						// Instantiate the map:
						var map = new H.Map(
						  document.getElementById('mapContainer'),
						  defaultLayers.normal.map,
						  {
						  zoom: 14, 
						  center: { lat: 14.601147, lng: 120.985659 },
						  });

						// Create the parameters for the routing request:
						var routingParameters = {
						  // The routing mode:
						  'mode': 'fastest;car',
						  // The start point of the route:
						  'waypoint0': 'geo!' + firstLat + ',' + firstLong,
						  // The end point of the route:
						  'waypoint1': 'geo!' + secLat + ',' + secLong,
						  // To retrieve the shape of the route we choose the route
						  // representation mode 'display'
						  'representation': 'display'
						}; 
						// Define a callback function to process the routing response:
						var onResult = function(result) {
						  var route,
						    routeShape,
						    startPoint,
						    endPoint,
						    strip;
						  if(result.response.route) {
								  // Pick the first route from the response:
								  route = result.response.route[0];
								  // Pick the route's shape:
								  routeShape = route.shape;

								  // Create a strip to use as a point source for the route line
								  strip = new H.geo.Strip();

								  // Push all the points in the shape into the strip:
								  routeShape.forEach(function(point) {
								    var parts = point.split(',');
								    strip.pushLatLngAlt(parts[0], parts[1]);
								  });

								  // Retrieve the mapped positions of the requested waypoints:
								  startPoint = route.waypoint[0].mappedPosition;
								  endPoint = route.waypoint[1].mappedPosition;

								  // Create a polyline to display the route:
								  var  routeLine = new H.map.Polyline(strip, {
 										 style: { lineWidth: 10 },
  										arrows: { fillColor: 'white', frequency: 2, width: 0.8, length: 0.7 }
									});

								  // Create a marker for the start point:
								  var startMarker = new H.map.Marker({
								    lat: startPoint.latitude,
								    lng: startPoint.longitude
								  });

								  // Create a marker for the end point:
								  var endMarker = new H.map.Marker({
								    lat: endPoint.latitude,
								    lng: endPoint.longitude
								  });

								  // Add the route polyline and the two markers to the map:
								  map.addObjects([routeLine, startMarker, endMarker]);

								  // Set the map's viewport to make the whole route visible:
								  map.setViewBounds(routeLine.getBounds());
						  }
						};

						// Get an instance of the routing service:
						var router = platform.getRoutingService();

						// Call calculateRoute() with the routing parameters,
						// the callback and an error callback function (called if a
						// communication error occurs):
						router.calculateRoute(routingParameters, onResult,
						  function(error) {
						    alert(error.message);
						});

					 
					    /* HERE API END */

				}  
		    });
		}
 
	      
	}

	

	// get quick access data in json
	/* 
  	$http.get('https://places.cit.api.here.com/places/v1/autosuggest?at=40.74917,-73.98529&q=chrysler&app_id=XrO29mOZYrddKOcalMB0&app_code=MG9xBPwbf5UTj9pCnF-6Rw&tf=plain&pretty=true').success(function(data ){
		
		//console.log(data.results);
		$scope.findplaces = data.results;
  	}); 
 
  	$http.get('https://traffic.cit.api.here.com/traffic/6.0/incidents.json?app_id=fyT2mQLeAUaFZFjajBqe&app_code=mdqF2xWZpvn1Iqf4SpuiTQ').success(function(data ){
		
		console.log(data);
		 
  	}); */

  		


}]);