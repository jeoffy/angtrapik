'use strict';

angular.module('roadTraffic.traffic', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/traffic', {
    templateUrl: 'traffics/traffic.html',
    controller: 'TrafficCtrl'
  });
}])

.controller('TrafficCtrl', ['$scope', '$location', '$route', function($scope, $location, $route) {
	 
	// from quick access paramters
	var param = null;
    $scope.submit = function(param) {

    	  
		//console.log(param);
		// if parameters exist and not null
		if (param != null){
			$scope.addressLoc = param;
			console.log($scope.addressLoc); 
		}else{
			console.log('No quick access');
		}

        if ($scope.addressLoc) { 

        	$('#trafficUpdate, #streetView, .refresh-loc, #mapResult').css('display', 'block');
        	$('#input-search').removeClass('col-md-12').addClass('col-md-11');


        	function initialize() {

	          	var geocoder = new google.maps.Geocoder();
	    	  	var address = $scope.addressLoc;
	    	  	console.log(address); 

	    	 	geocoder.geocode( { 'address': address}, function(results, status) {

		    	  	if (status == google.maps.GeocoderStatus.OK) {
		    	  		//alert('YES!');
		    	  		var latitude = results[0].geometry.location.lat();
		            	var longitude = results[0].geometry.location.lng();
		            	var latlong = 'Latitude: ' + latitude +  ' / '  +  ' Longitude: ' + longitude;
		            	console.log(latitude + ', ' + longitude);


			            var getTrafficLayer = new google.maps.Map(document.getElementById('trafficUpdate'), {
			              zoom: 16,
			              center: new google.maps.LatLng(latitude,longitude),
			              mapTypeId: google.maps.MapTypeId.ROADMAP,
			              backgroundColor: '#fff',
			              disableDoubleClickZoom: true,
			              draggable: true,
			              scrollwheel: true,
			              panControl: true,
			              disableDefaultUI: false,
			              fullscreenControl: true,
			              styles: [
			                  {
			                    featureType: 'all',
			                    stylers: [
			                      { saturation: -80 }
			                    ]
			                  },{
			                    featureType: 'road.arterial',
			                    elementType: 'geometry',
			                    stylers: [
			                      { hue: '#00ffee' },
			                      { saturation: 50 }
			                    ]
			                  }
			                ],
			                streetViewControl: true

			            });


			            /* Styling the map */
			            var marker = new google.maps.Marker({
			               position: getTrafficLayer.getCenter(),
			               icon: 'img/traffic.png',
			               draggable: false,
			               map: getTrafficLayer
			             });
			            var contentString = 'Latitude: ' + latitude + ' / ' + 'Longitude' + longitude;
			            
			            /*
			            var infowindow = new google.maps.InfoWindow({
			               content: '<div id="info-content">Drag this   icon to change location of the street view</div>',
			               pixelOffset: new google.maps.Size(0,50)
			            });
			            infowindow.open(getTrafficLayer, marker);
			            setInterval(function(){ infowindow.close(getTrafficLayer, marker)}, 2500); 
						*/

			            /* End styling the map */

			            var trafficLayer = new google.maps.TrafficLayer();
			            trafficLayer.setMap(getTrafficLayer);


			            // STreet view
			            var fenway = {lat: latitude, lng: longitude};
			            var panorama = new google.maps.StreetViewPanorama(
			              document.getElementById('streetView'), {
			                position: fenway,
			                pov: {
			                  heading: 24,
			                  pitch: 3
			                }
			              });

			            getTrafficLayer.setStreetView(panorama);

			            $scope.error = null;
			            $scope.latlongInfo = latlong;
			            

			            

			        }else{
			          $scope.error = "Please double check your location!";
			    	}

	    	  	}); 

    		} 	
			
    		return initialize();

        }
    }; 

}]);